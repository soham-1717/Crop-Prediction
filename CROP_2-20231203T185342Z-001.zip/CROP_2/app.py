from flask import Flask, render_template, request, redirect, url_for, session
import joblib
import pandas as pd
import numpy as np
from sklearn.neural_network import MLPClassifier

app = Flask(__name__)
app.secret_key = 'supersecretkey'
# Load the label encoder, one-hot encoder, and trained model
label_encoder = joblib.load('label_encoder.pkl')
one_hot_encoder = joblib.load('one_hot_encoder.pkl')
model = joblib.load('trained_model.pkl')

name = ''
place = ''
# Load the crop data
data = pd.read_csv('cpdata - cpdata.csv')
y = data['label']
label_encoder.fit(y)

# Initialize the predictions dataframe
predictions_df = pd.DataFrame(columns=[ 'temperature', 'humidity', 'ph', 'rainfall', 'label','season','soil type','name','place'])

# Define a function to make predictions
def make_predictions( temperature, humidity, ph, rainfall,season,soil_type):
    global predictions_df
    X=[temperature, humidity, ph, rainfall,season,soil_type]

    data_df = pd.DataFrame([X],columns = ['temperature', 'humidity', 'ph', 'rainfall','season','soil type'])

    # Extract the categorical features
    cat_features = ['season', 'soil type']
    cat_feature_values = data_df[cat_features].values.reshape(1, -1)
    one_hot_encoded = one_hot_encoder.transform(cat_feature_values)
    X_encoded = np.concatenate([data_df[['temperature', 'humidity', 'ph', 'rainfall']].values.flatten(), one_hot_encoded.flatten()])
    X_encoded = X_encoded.reshape(1, -1)

    y_pred_encoded = model.predict(X_encoded)
    label = label_encoder.inverse_transform(y_pred_encoded.astype(int))
    
    
    return label

# Define the landing page route
@app.route('/landing', methods=['GET', 'POST'])
def landing():
    global predictions_df
    if request.method == 'POST':
        # Store the user's information in session variables
        session['name'] = request.form['name']
        session['city'] = request.form['city']
        session['state'] = request.form['state']
        session['taluka'] = request.form['taluka']
        session['mobile'] = request.form['mobile']
       
        return redirect(url_for('home'))
    else:
        print(session)
        return render_template('landing.html')


# Define the home page route
@app.route('/')
def home():
    # Check if the user has entered their name and place
    if 'name' in session and 'city' in session:
        return render_template('index.html')
    else:
        # Redirect to the landing page if not
        return redirect(url_for('landing'))

# Define the predict route
@app.route('/predict', methods=['POST'])
def predict():
    global predictions_df
    # Get the user's inputs from the form

    temperature = float(request.form['temperature'])
    humidity = float(request.form['humidity'])
    ph = float(request.form['ph'])
    rainfall = float(request.form['rainfall'])
    season = str(request.form['season'])
    soil_type = str(request.form['soil_type'])

    
    # Make a prediction using the model
    prediction = make_predictions( temperature, humidity, ph, rainfall,season,soil_type)

    # Add the prediction to the dataframe
    predictions_df = predictions_df.append({
        'temperature': temperature,
        'humidity': humidity,
        'ph': ph,
        'rainfall': rainfall,
        'season': season,
        'soil type': soil_type,
        'label': prediction[0],
        'name':session['name'],
        'state':session['state'],
        'city':session['city'],
        'taluka':session['taluka'],
        'mobile':session['mobile'],
    }, ignore_index=True)

    # Render the results template with the prediction
    return render_template('result.html', prediction=prediction)

# Define the login page route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Check if the username and password are correct
        if request.form['username'] == 'admin' and request.form['password'] == 'password':
            # Store the user's information in a session
            session['logged_in'] = True
            session['username'] = request.form['username']
            return redirect(url_for('records'))
        else:
            return render_template('login.html', error='Invalid username or password')
    else:
        return render_template('login.html')

# Define the logout route
@app.route('/logout')
def logout():
    # Remove the user's information from the session
    session.pop('logged_in', None)
    session.pop('username', None)
    return redirect(url_for('home'))

# Define the records page route
@app.route('/records')
def records():
    # Check if the user is logged in
    if 'logged_in' in session and session['logged_in'] == True:
        # Render the records template
        return render_template('records.html', data=predictions_df)
    else:
        # Redirect to the login page
        return redirect(url_for('login'))

# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True, port = 5005)
